import joblib

model = joblib.load('model.joblib')