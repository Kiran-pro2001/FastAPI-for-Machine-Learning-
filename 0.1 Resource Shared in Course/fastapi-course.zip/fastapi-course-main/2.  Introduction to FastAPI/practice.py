def add_integers(a: int, b: int) -> int:
    return a + b


print(add_integers(3.5, 5.5))